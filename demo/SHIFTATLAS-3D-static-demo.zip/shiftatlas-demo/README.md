# SHIFTATLAS built demo

Requires Node.js 22 LTS. No npm install is needed for this prebuilt snapshot.

Windows: extract the ZIP, open the shiftatlas-demo folder and run START-DEMO.cmd. Then visit http://127.0.0.1:3107. Keep the terminal open while presenting; close it or press Ctrl+C to stop.

Other systems: from this folder run `node serve.mjs` and open http://127.0.0.1:3000.

Do not open out/index.html directly. Use fictional profiles only. Source links need internet; calculations and the bundled data run locally. Full source, provenance, disclosure and submission preparation are in the companion source ZIP.

The demo uses a synthetic skill rubric and hypothetical scenarios, not employment probabilities or validated labour-demand forecasts. See docs/VERIFICATION.md for executed browser checks and outstanding device acceptance. Atlas Quest is at /atlas/?module=quest; the profile/resume studio is at /atlas/?module=skills.
