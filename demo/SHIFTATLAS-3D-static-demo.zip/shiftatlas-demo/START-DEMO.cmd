@echo off
cd /d "%~dp0"
set PORT=3107
echo Open http://127.0.0.1:3107 in your browser. Keep this window open.
node serve.mjs
pause
